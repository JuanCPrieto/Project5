

import java.io.File;
import java.io.FileNotFoundException;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Class: CMSC203 
 * Instructor: Gary Thai
 * Description: (Give a brief description for each Class)
 * Due: 04/21/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto__
*/

public class TwoDimRaggedArrayUtility 
{
	/** Is the an empty constructor
	 */
	public TwoDimRaggedArrayUtility()
	{
		
	}
	
	/** It reads the file and copy its contest in a double array
	 * 
	 * @param file the actual file to read
	 * @param high The bonus for the highest in its category
	 * @param low The bonus for the lowest in the category
	 * @param other The bonus for all other in the category
	 * @return An array with bonuses for the categories
	 */
	public static double[][] readFile(File file) throws FileNotFoundException
	{
		int numberOfRows = 0;
		
		double[][] arrayOfFile = new double[10][10];
		double[][] newArray = new double[numberOfRows][10];
		
		 
		Scanner keyword = new Scanner(file);
		
		
		
		while (keyword.hasNextLine())
		{
			for (int index = 0; index < arrayOfFile.length; index++)
			{
				String[] line = keyword.nextLine().trim().split(" ");
				
				for (int c = 0; c < line.length; c++) 
				 {
					 arrayOfFile[index][c] = Double.parseDouble(line[c]);
				 }
			}
		}
		while (keyword.hasNextLine())
		{
			numberOfRows++;
			keyword.nextLine();
		}

		return arrayOfFile;
		
	}
	
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException
	{
		 FileWriter writer;
		try {
			writer = new FileWriter(outputFile);
		
		 for (int i = 0; i < data.length; i++) 
		 {
				
			 for (double[] row : data) 
			 {
			        for (double num : row)
			        {

			            writer.write(num + " ");
			        }
			        writer.write("\n"); // start a new line for each row
			}
			    writer.close();
		 }
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	}
	
	/** Gets the total of all the elements in the array
	 * 
	 * @param data The 2d array that is required 
	 * @return The total of the array
	 */
	public static double getTotal(double[][] data)
	{
		double total = 0;
		
		for (int row = 0; row < data.length; row++)
		{

			for (int col = 0; col < data[row].length; col++)
			{
			total += data[row][col];
			}
		} 
		
		return total;
	
	}
	/** Gets the average of all the elements in the array
	 * 
	 * @param data The 2d array that is required 
	 * @return The average of the array
	 */
	public static double getAverage(double[][] data)
	{
		double total = 0;
		double average = 0;
		
		
		for (int row = 0; row < data.length; row++)
		{
			for (int col = 0; col < data[row].length; col++)
			{
				total += data[row][col];
				average = total / data.length;
			}
		} 
		
		return average;
	
	}
	
	/** Gets the total for all rows of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param row the number if rows required 
	 * @return The total of all rows of the array
	 */
	public static double getRowTotal(double[][] data, int row)
	{
		double rowTotal = 0.0;
	    for (int i = 0; i < data[row].length; i++) 
	    {
	        rowTotal += data[row][i];
	    }
	    return rowTotal;

	}
	
	/** Gets the total for all columns of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param col the number if columns required 
	 * @return The total of all columns of the array
	 */
	public static double getColumnTotal(double[][] data, int col)
	{
		 double colTotal = 0.0;
		 
		    for (int i = 0; i < data.length; i++) 
		    {
		        if (data[i].length > col) 
		        {
		            colTotal += data[i][col];
		        }
		    }
		    return colTotal;
	}
	
	/** Gets the highest value in the rows of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param row the number if rows required 
	 * @return The highest in the rows of the array
	 */
	public static double getHighestInRow(double[][] data, int row)
	{
		 double highestInRow = data[row][0];
		 
		    for (int i = 1; i < data[row].length; i++) 
		    {
		        if (data[row][i] > highestInRow) 
		        {
		            highestInRow = data[row][i];
		        }
		    }
		    return highestInRow;
	}
	
	/** Gets the index of the highest value in the rows of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param row the number if rows required 
	 * @return The index of the highest value in the rows of the array
	 */
	public static int getHighestInRowIndex(double[][] data, int row)
	{
		int highestIndex = 0;
		
	    for (int i = 1; i < data[row].length; i++)
	    {
	        if (data[row][i] > data[row][highestIndex])
	        {
	            highestIndex = i;
	        }
	    }
	    return highestIndex;
	}
	
	/** Gets the lowest value in the rows of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param row the number if rows required 
	 * @return The lowest value in the rows of the array
	 */
	public static double getLowestInRow(double[][] data, int row)
	{
		double lowestInRow = data[row][0];
		
	    for (int i = 1; i < data[row].length; i++) 
	    {
	        if (data[row][i] < lowestInRow) 
	        {
	            lowestInRow = data[row][i];
	        }
	    }
	    return lowestInRow;
	}
	
	/** Gets the index of the lowest value in the rows of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param row the number if rows required 
	 * @return The index of the lowest value in the rows of the array
	 */
	public static double getLowestInRowIndex(double[][] data, int row)
	{
		int lowestIndex = 0;
		
	    for (int i = 1; i < data[row].length; i++) 
	    {
	        if (data[row][i] < data[row][lowestIndex]) 
	        {
	            lowestIndex = i;
	        }
	    }
	    return lowestIndex; 
	}
	
	/** Gets the highest value in the columns of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param col the number if columns required 
	 * @return The highest value in the columns of the array
	 */
	public static double getHighestInColumn(double[][] data, int col)
	{
		double highestInCol = Double.MIN_VALUE;
		int i = 0;
		
	    while (i < data.length) 
	    {
	        if (col < data[i].length) 
	        {
	        	if  (data[i][col] > highestInCol) 
	        	{	
	        		highestInCol = data[i][col];
	        	}
	        }
	      i++;
	    }
	    
	    return highestInCol;
	}
	
	/** Gets the index of the highest value in the columns of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param col the number if columns required 
	 * @return The index of the lowest value in the rows of the array
	 */
	public static int getHighestInColumnIndex(double[][] data, int col)
	{
		int highestIndex = 0;
		
	    for (int i = 1; i < data[col].length; i++) 
	    {
	        if (data[i][col] > data[highestIndex][col])
	        {
	            highestIndex = i;
	        }
	    }
	    return highestIndex;
	}
	
	/** Gets the lowest value in the columns of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param col the number if columns required 
	 * @return the lowest value in the columns of the array
	 */
	public static double getLowestInColumn(double[][] data, int col)
	{
		double lowestInCol = Double.MAX_VALUE;
		
	    for (int i = 0; i < data.length; i++) 
	    {
	        if (data[i].length > col) 
	        {
	        	if (data[i][col] < lowestInCol)
	        	{
					lowestInCol = data[i][col];
	        	}	
	        }
	    }
	    return lowestInCol;
	
	}
	
	/** Gets the index of the lowest value in the columns of the array
	 * 
	 * @param data The 2d array that is required 
	 * @param col the number if columns required 
	 * @return The index of the lowest value in the columns of the array
	 */
	public static double getLowestInColumnIndex(double[][] data, int col)
	{
	        
	        double minValue = Double.MAX_VALUE;
	        int minIndex = 0;

	        for (int i = 0; i < data.length; i++) 
	        {
	            if (col < data[i].length && data[i][col] < minValue)
	            {
	                minValue = data[i][col];
	                minIndex = i;
	            }
	        }
	        return minIndex;
	}
	
	/** Gets the highest value in the array
	 * 
	 * @param data The 2d array that is required  
	 * @return The highest value in the array
	 */
	public static double getHighestInArray(double[][] data)
	{
		double maxValue = data[0][0];

        for (int row = 0; row < data.length; row++) 
        {
            for (int col = 0; col < data[row].length; col++) 
            {
                if (data[row][col] > maxValue) 
                {
                    maxValue = data[row][col];
                }
            }
        }

        return maxValue;
	}
	
	/** Gets the lowest value in the array
	 * 
	 * @param data The 2d array that is required  
	 * @return The lowest value in the array
	 */
	public static double getLowsetInArray(double[][] data)
	{
		double minValue = data[0][0];

        for (int row = 0; row < data.length; row++) 
        {
            for (int col = 0; col < data[row].length; col++) 
            {
                if (data[row][col] < minValue) 
                {
                    minValue = data[row][col];
                }
            }
        }

        return minValue;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
