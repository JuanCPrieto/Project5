
/*
 * Class: CMSC203 
 * Instructor: Gary Thai
 * Description: (Give a brief description for each Class)
 * Due: 04/17/2023
 * Platform/compiler:
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: _Juan_Prieto_
*/

public class HolidayBonus 
{
	private static final double HIGHEST_SALES_BONUS = 100.0;
    private static final double LOWEST_SALES_BONUS = 50.0;
    private static final double OTHER_STORES_BONUS = 25.0;

	
	/** Calculates the holiday bonus for multiple categories
	 * 
	 * @param data The 2d array to work with
	 * @param high The bonus for the highest in its category
	 * @param low The bonus for the lowest in the category
	 * @param other The bonus for all other in the category
	 * @return An array with bonuses for the categories
	 */
    
    public static double[] calculateHolidayBonus(double[][] salesArray) 
    {
        double[] holidayBonuses = new double[salesArray.length];

        for (int row = 0; row < salesArray.length; row++) 
        {
            for (int col = 0; col < salesArray[row].length; col++) 
            {
                double sales = salesArray[row][col];

                if (sales == TwoDimRaggedArrayUtility.getHighestInColumn(salesArray, col)) 
                {
                    holidayBonuses[row] += HIGHEST_SALES_BONUS;
                } 
                else if (sales == TwoDimRaggedArrayUtility.getLowestInColumn(salesArray, col))
                {
                    holidayBonuses[row] += LOWEST_SALES_BONUS;
                } 
                else 
                {
                    holidayBonuses[row] += OTHER_STORES_BONUS;
                }
            }
        }

        return holidayBonuses;
    }
	
	/** Calculates the total of all bonuses for every category
	 * 
	 * @param data The 2d array to be queried
	 * @param high The bonus for the category with the highest sales
	 * @param low The bonus for the category with the lowest sales
	 * @param other The bonus for all other categories
	 * @return The total of all bonuses for all categories
	 */
    public static double calculateTotalHolidayBonus(double[][] salesArray) 
    {
        double totalHolidayBonus = 0.0;
        double[] holidayBonuses = calculateHolidayBonus(salesArray);
        
        for (double bonus : holidayBonuses) 
        {
            totalHolidayBonus += bonus;
        }

        return totalHolidayBonus;
    }
	
}
